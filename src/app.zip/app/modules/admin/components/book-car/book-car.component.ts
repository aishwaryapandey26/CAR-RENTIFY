import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';


import { Router } from '@angular/router';
import { NzMessageService } from 'ng-zorro-antd/message';
import { StorageService } from 'src/app/auth/components/services/storage/storage.service';
import { CustomerService } from 'src/app/modules/customer/services/customer.service';

@Component({
  selector: 'app-book-car',
  templateUrl: './book-car.component.html',
  styleUrls: ['./book-car.component.scss']  // Corrected the property name to `styleUrls`
})
export class BookCarComponent implements OnInit {  // Implementing `OnInit` lifecycle hook

  carId: number = this.activatedRoute.snapshot.params['id'];  // Properly accessing route params
  car: any;  // Car details fetched from the service
  processedImage: string | undefined;  // Processed image in base64 format
  validateForm!: FormGroup;  // Form group for date input
  isSpinning: boolean = false;  // Correcting the type for spinner state
  dateFormat!: "DD-MM-YYYY";

  constructor(
    private service: CustomerService,
    private activatedRoute: ActivatedRoute,
    private fb: FormBuilder,
    private message:NzMessageService,
    private router:Router
  ) {}

  ngOnInit(): void {
    this.validateForm = this.fb.group({
      toDate: [null, Validators.required],
      fromDate: [null, Validators.required],
    });
    this.getCarById();
  }

  getCarById(): void {
    this.isSpinning = true;
    this.service.getCarById(this.carId).subscribe(
      (res) => {
        this.car = res;  // Assign the response to `car` for use in the template
        this.processedImage = 'data:image/jpeg;base64,' + res.returnedImage;  // Handle the image processing
        this.isSpinning = false;  // Stop the spinner once data is loaded
      },
      (err) => {
        console.error('Error fetching car details:', err);
        this.isSpinning = false;  // Stop the spinner if an error occurs
      }
    );
  }

  bookACar(date: any) {
    console.log(date); // Log the date object for debugging
    this.isSpinning = true; // Start the spinner

    // Create the DTO with correct mappings
    let bookCarDto = {
      fromDate: date.fromDate, // Corrected fromDate to match form
      toDate: date.toDate,     // Corrected toDate to match form
      userId: StorageService.getUserId(), // Assuming this gets user ID
      carId: this.carId        // Car ID retrieved from the route params
    };

    // Call the service to book the car
    this.service.bookACar(bookCarDto).subscribe(
      (res) => {
        console.log(res); // Log the response
        this.message.success("Booking request submitted successfully", { nzDuration: 5000 });
        this.router.navigateByUrl("/customer/dashboard"); // Navigate to dashboard after successful booking
        this.isSpinning = false; // Stop the spinner
      },
      (error) => {
        console.error(error); // Log the error
        this.message.error("Something went wrong", { nzDuration: 5000 }); // Show error message
        this.isSpinning = false; // Stop the spinner
      }
    );
}
}
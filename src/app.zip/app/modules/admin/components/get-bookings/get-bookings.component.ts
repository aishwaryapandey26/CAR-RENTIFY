import { Component } from '@angular/core';
import { NzMessageService } from 'ng-zorro-antd/message';
import { AdminServiceService } from '../../services/admin.service';

@Component({
  selector: 'app-get-bookings',
  templateUrl: './get-bookings.component.html',
  styleUrls: ['./get-bookings.component.scss'] // Fixed here
})
export class GetBookingsComponent {

  bookings: any;
  isSpinning: boolean = false; // Initialize as false

  constructor(private adminService: AdminServiceService,
    private message:NzMessageService
  ) {
    this.getBookings(); // Call to fetch bookings
   
  }

  getBookings() {
    this.isSpinning = true;

    this.adminService.getCarBookings().subscribe((res) => {
      this.isSpinning = false; // Set spinning to false after receiving data
      this.bookings = res; // Assign the response to bookings
      console.log(this.bookings); // Optional: Keep the log for debugging
    }, (error) => {
      this.isSpinning = false; // Ensure spinning is turned off on error
      console.error(error); // Log any error for debugging
    });
  }

  changeBookingStatus(bookingId:number,status:string){
this.isSpinning=true;
console.log(bookingId,status);
this.adminService.changeBookingStatus(bookingId,status).subscribe((res)=>{
  this.isSpinning=false;
  console.log(res);
  this.getBookings();
  this.message.success("booking status changed successfully"),{nzDuration:5000}
}, error=>{
  this.message.error("Somethin went wrong",{nzDuration:5000}); 
})

  }
}

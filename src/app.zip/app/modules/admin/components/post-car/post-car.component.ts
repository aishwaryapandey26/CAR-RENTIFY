import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { NzMessageService } from 'ng-zorro-antd/message';
import { AdminServiceService } from '../../services/admin.service';

@Component({
  selector: 'app-post-car',
  templateUrl: './post-car.component.html',
  styleUrls: ['./post-car.component.scss'] // Corrected: Changed 'styleUrl' to 'styleUrls'
})
export class PostCarComponent {
  postCarform!: FormGroup;
  isSpinning: boolean = false; // Initial spinning state
  selectedFile: File | null | undefined; // File selected by the user
  imagePreview: string | ArrayBuffer | null = null; // Image preview
 
  
  // Dropdown lists for form  listOfBrands = ["BMW", "AUDI", "FERRARI", "TESLA", "VOLVO", "TOYOTA", "HONDA", "FORD"];
  listOfOption: Array<{ label: string; value: string }> = [];
listOfBrands=["BMW","AUDI","FERRARI","TESLA","VOLVO","TOYOTA","HONDA","FORD","NISSAN","HYUNDAI"];
  listOfType = ["Petrol", "Hybrid", "Diesel", "Electric", "CNG"];
  listOfColor = ["Red", "Black", "White", "Blue", "Orange", "Grey", "Silver"];
  listOfTransmission = ["Manual", "Automatic"];
 listOfPrices = ["20,000 USD", "25,000 USD", "30,000 USD", "35,000 USD"];

  constructor(private fb: FormBuilder,
    private adminService:AdminServiceService,
    private message:NzMessageService,
    private router:Router
  ) {}

  ngOnInit() {
    // Initialize the form with validators
    this.postCarform = this.fb.group({
      name: [null, Validators.required],
      brand: [null, Validators.required],
      type: [null, Validators.required],
      color: [null, Validators.required],
      transmission: [null, Validators.required],
      price: [null, Validators.required],
      description: [null, Validators.required],
      year: [null, Validators.required]
    });
  }

  // Method to handle form submission
  postCar() {
    if (this.postCarform.valid) {
      console.log(this.postCarform.value);
      const formData: FormData = new FormData();
      if (this.selectedFile) {
        formData.append('img', this.selectedFile); // Append the selected file
      }
      formData.append('brand', this.postCarform.get('brand')?.value); // Using postCarform here
      formData.append('name', this.postCarform.get('name')?.value);
      formData.append('type', this.postCarform.get('type')?.value);
      formData.append('color', this.postCarform.get('color')?.value);
      formData.append('year', this.postCarform.get('year')?.value);
      formData.append('transmission', this.postCarform.get('transmission')?.value);
      formData.append('description', this.postCarform.get('description')?.value);
      formData.append('price', this.postCarform.get('price')?.value);
      console.log(formData);
      this.adminService.postCar(formData).subscribe((res)=>{
        this.isSpinning=false;
        this.message.success("car posted successfully",{nzDuration:5000});
        this.router.navigate(['/admin/dashboard']);

        console.log(res);
      })
    } else {
      console.log('Form is invalid');
    }
  }

  // Method to handle file selection and preview
  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0];
    this.previewImage();
  }

  // Method to preview the selected image
  previewImage() {
    if (this.selectedFile) {
      const reader = new FileReader();
      reader.onload = () => {
        this.imagePreview = reader.result;
      };
      reader.readAsDataURL(this.selectedFile);
    }
  }
}

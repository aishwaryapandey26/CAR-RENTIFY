import { Component } from '@angular/core';
import { CustomerService } from 'src/app/modules/customer/services/customer.service';

@Component({
  selector: 'app-my-bookings',
  templateUrl: './my-bookings.component.html',
  styleUrls: ['./my-bookings.component.scss'] // Fixed here
})
export class MyBookingsComponent {
  bookings: any;
  basicTableData: any;
  isSpinning: boolean = false; // Initialize as false

  constructor(private service: CustomerService) {
    this.getMyBookings();
  }

  getMyBookings() {
    this.isSpinning = true;
    this.service.getBookingsByUserId().subscribe((res) => {
      this.isSpinning = false;
      this.bookings = res;
      this.basicTableData = this.bookings; // Assign bookings to basicTableData
    });
  }
}

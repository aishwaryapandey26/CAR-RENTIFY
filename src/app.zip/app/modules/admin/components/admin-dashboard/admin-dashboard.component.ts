import { Component } from '@angular/core';
import { NzMessageService } from 'ng-zorro-antd/message';
import { AdminServiceService } from '../../services/admin.service';
@Component({
  selector: 'app-admin-dashboard',
 
  templateUrl: './admin-dashboard.component.html',
  styleUrl: './admin-dashboard.component.scss'
})
export class AdminDashboardComponent {
  cars:any=[];
  constructor(private adminService: AdminServiceService,
    private message:NzMessageService
  ){}
    ngOnInit(){
      this.getAllCars();
    }
   
    getAllCars() {
      this.adminService.getAllCars().subscribe((res) => {
        console.log(res);
        res.forEach((element: any) => {  // Corrected forEach syntax and used 'element'
          element.processesImg = 'data:image/jpeg;base64,' + element.returnedImage;  // Fixed 'elementAt'
          this.cars.push(element);  // Push the element to the 'cars' array
        });
      });
    }
    deleteCar(carId: number) {
      this.adminService.deleteCar(carId).subscribe((res) => {
        console.log('Car deleted:', res);
        // Optionally, update the list of cars after deletion
        this.cars = this.cars.filter((car: { id: number; }) => car.id !== carId);
      this.getAllCars();
      this.message.success("car deleted successfully",{nzDuration:5000});
      });
      



    }}

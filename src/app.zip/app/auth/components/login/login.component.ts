import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router'; // Correct import for Router
import { NzMessageService } from 'ng-zorro-antd/message'; // Import NzMessageService
import { AuthService } from '../services/auth/auth.service';
import { StorageService } from '../services/storage/storage.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {

  isSpinning: boolean = false;
  loginForm!: FormGroup;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router, // Correct usage of Angular's Router
    private message: NzMessageService // Inject NzMessageService for displaying messages
  ) {}

  ngOnInit() {
    // Initialize login form with validators
    this.loginForm = this.fb.group({
      email: [null, [Validators.email, Validators.required]],
      password: [null, [Validators.required]]
    });
  }

  login() {
    // Start the spinner
    this.isSpinning = true;

    // Call the AuthService to log in
    this.authService.login(this.loginForm.value).subscribe(
      (res) => {
        console.log(res);

        if (res.userId != null) {
          const user = {
            id: res.userId,
            role: res.userRole
          };

          // Assuming StorageService uses static methods
          StorageService.saveUser(user);
          StorageService.saveToken(res.jwt);

          // Navigate to the appropriate dashboard
          if (StorageService.isAdminLoggedIn()) {
            this.router.navigateByUrl("/admin/dashboard");
          } else if (StorageService.isCustomerLoggedIn()) {
            this.router.navigateByUrl("/customer/dashboard");
          } else {
            this.message.error("Bad credentials", { nzDuration: 5000 });
          }
        }

        // Stop the spinner after the response
        this.isSpinning = false;
      },
      (err) => {
        console.error('Login error', err);
        this.message.error("Login failed. Please try again.", { nzDuration: 5000 });
        
        // Stop the spinner on error
        this.isSpinning = false;
      }
    );
  }
}

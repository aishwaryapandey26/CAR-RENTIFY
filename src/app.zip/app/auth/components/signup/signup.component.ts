import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router'; // Change here
import { NzMessageService } from 'ng-zorro-antd/message';
import { AuthService } from '../services/auth/auth.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss'],
})
export class SignupComponent implements OnInit {
  isSpinning = false;
  signupForm!: FormGroup;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private message: NzMessageService,
    private router: Router
  ) {}

  ngOnInit() {
    this.signupForm = this.fb.group({
      name: [null, [Validators.required]],
      email: [null, [Validators.required, Validators.email]],
      password: [null, [Validators.required, Validators.minLength(8)]],
      confirmPassword: [null, [Validators.required, this.confirmationValidate.bind(this)]], // Bind 'this' to access signupForm
      username: [null, [Validators.required]],
    });
    
    console.log(this.signupForm.controls); // Verify that the controls are initialized correctly
  }

  confirmationValidate(control: FormControl): { [s: string]: boolean } | null {
    if (!control.value) {
      return { required: true };
    } else if (control.value !== this.signupForm.get('password')?.value) {
      return { confirm: true, error: true };
    }
    return null;
  }

  register() {
    if (this.signupForm.valid) {
      this.isSpinning = true; // Show spinner while making API call
      console.log('Form Data:', this.signupForm.value); // Log the data
      this.authService.register(this.signupForm.value).subscribe({
        next: (res) => {
          console.log('Registration successful', res);
          this.isSpinning = false; // Hide spinner once request is done
          if (res.id != null) {
            this.message.success("Signup successful", { nzDuration: 5000 });
            this.router.navigateByUrl("/login"); // Change to navigateByUrl
          } else {
            this.message.error("Something went wrong", { nzDuration: 5000 });
          }
        },
        error: (err) => {
          console.error('Registration failed', err);
          this.isSpinning = false; // Hide spinner even if request fails
          this.message.error("Something went wrong", { nzDuration: 5000 });
        }
      });
    } else {
      console.log('Form is invalid');
    }
  }

  onSubmit() {
    this.register(); // Call the register method on form submit
  }
}
